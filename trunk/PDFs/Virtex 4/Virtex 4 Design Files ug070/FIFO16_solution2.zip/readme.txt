**********************************************************************
**  Disclaimer: LIMITED WARRANTY AND DISCLAMER. These designs are
**              provided to you "as is". Xilinx and its licensors make and you
**              receive no warranties or conditions, express, implied,
**              statutory or otherwise, and Xilinx specifically disclaims any
**              implied warranties of merchantability, non-infringement,or
**              fitness for a particular purpose. Xilinx does not warrant that
**              the functions contained in these designs will meet your
**              requirements, or that the operation of these designs will be
**              uninterrupted or error free, or that defects in the Designs
**              will be corrected. Furthermore, Xilinx does not warrantor
**              make any representations regarding use or the results of the
**              use of the designs in terms of correctness, accuracy,
**              reliability, or otherwise.
**
**              LIMITATION OF LIABILITY. In no event will Xilinx or its
**              licensors be liable for any loss of data, lost profits,cost
**              or procurement of substitute goods or services, or for any
**              special, incidental, consequential, or indirect damages
**              arising from the use or operation of the designs or
**              accompanying documentation, however caused and on any theory
**              of liability. This limitation will apply even if Xilinx
**              has been advised of the possibility of such damage. This
**              limitation shall apply not-withstanding the failure of the
**              essential purpose of any limited remedies herein.
**
**  Copyright (c) 2007 Xilinx, Inc.
**  All rights reserved
**
******************************************************************************

Revision Note 


******************************************************************************
solution2.zip file contains the following files

fifo_third_clk.v
fifo_third_clk_flags.v

fifo_third_clk.vhd
fifo_third_clk_flags.vhd
FIFO16.vhd

The AF/AE offset values for the FIFO16 are outside the range listed in the user 
guide and in the library models (http://direct.xilinx.com/bvdocs/userguides/ug070.pdf,  pg.148, Table 4-13). 
Therefore 

�When running the design in ISE 

In order for the design to go thru place and route, the user needs to set the following   
environment variable

setenv XIL_PLACE_ALLOW_LOCAL_BUFG_ROUTING 1
setenv XIL_MAP_SKIP_LOGICAL_DRC 1

Without these variables set, ISE will error out saying that the offset values are not valid.

�If simulating in Verilog

Out of range offset values will cause a warning to  be issued, but the simulation will still run to a normal completion.

�If simulating in VHDL 

Out of range offset values will cause an error that terminates the simulation, so in this case 
the customer must replace the UNISIM model for FIFO16 with the modified UNISIM model provided in this zip file.


The following two lines were modified:

--     if ((fwft_var = '0') and ((rd_offset_int < 5) or (rd_offset_int > addr_limit_var - 4))) then -- old
       if ((fwft_var = '0') and ((rd_offset_int < 5) or (rd_offset_int > addr_limit_var - 2))) then -- new

--     if ((fwft_var = '0') and ((wr_offset_int < 4) or (wr_offset_int > addr_limit_var - 5))) then -- old
       if ((fwft_var = '0') and ((wr_offset_int < 1) or (wr_offset_int > addr_limit_var - 5))) then -- new
